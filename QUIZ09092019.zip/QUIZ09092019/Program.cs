﻿using System;

namespace QUIZ09092019
{
    class Program
    {
        static void Main(string[] args)
        {
           BangunDatar obj=new BangunDatar();
            
            obj.LuasPersegi();

            obj.LuasSegitiga();
            
            obj.LuasLingkaran();

               {
            BangunRuang obj2=new BangunRuang();

            obj2.VolumeBalok();

            obj2.VolumeKubus();
        }


        }
        
    }
    
}